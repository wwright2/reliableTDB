package com.tigerpt

import com.tigerpt.domain.*

class BootStrap {

    def init = { servletContext ->
        // Create some sample data if database is empty
        if (Patient.count() == 0) {
            log.info "Loading sample trauma data..."
            
            // Sample Patient 1
            def patient1 = new Patient(
                firstName: "John",
                lastName: "Doe",
                medicalRecordNumber: "MRN001",
                dateOfBirth: new Date() - 365 * 45, // 45 years old
                age: 45,
                ageUnits: "Years",
                sex: "Male",
                race: "White",
                ethnicity: "Not Hispanic or Latino",
                homeZipCode: "90210",
                homeState: "California",
                homeCity: "Los Angeles",
                homeCountry: "United States"
            ).save(flush: true, failOnError: true)
            
            // Sample Injury for Patient 1
            def injury1 = new Injury(
                patient: patient1,
                injuryIncidentDate: new Date() - 7,
                icd10PrimaryExternalCause: "V89.2",
                transportMode: "Ground Ambulance",
                edHospitalArrivalDate: new Date() - 7,
                initialEdSystolicBP: 110,
                initialEdPulseRate: 88,
                initialEdTemperature: 98.6,
                initialEdRespiratoryRate: 16,
                initialEdOxygenSaturation: 98,
                initialEdGcsTotal: 15,
                initialEdGcsEyes: 4,
                initialEdGcsVerbal: 5,
                initialEdGcsMotor: 6,
                primaryTraumaServiceType: "Trauma Surgery"
            ).save(flush: true, failOnError: true)
            
            // Sample Diagnosis
            new Diagnosis(
                injury: injury1,
                icd10InjuryDiagnosis: "S06.0",
                aisCode: "140602.3",
                aisVersion: "2015",
                bodyRegion: "Head",
                aisSeverity: 3
            ).save(flush: true, failOnError: true)
            
            // Sample Pre-existing Conditions
            new PreExistingCondition(
                patient: patient1,
                hypertension: true,
                diabetesMellitus: true,
                currentSmoker: false
            ).save(flush: true, failOnError: true)
            
            // Sample Outcome
            new Outcome(
                patient: patient1,
                totalIcuLengthOfStay: 3,
                totalVentilatorDays: 0,
                hospitalDischargeDisposition: "Home",
                hospitalDischargeDate: new Date() - 2,
                primaryMethodOfPayment: "Private Insurance"
            ).save(flush: true, failOnError: true)
            
            log.info "Sample trauma data loaded successfully"
        }
    }
    
    def destroy = {
    }
}
