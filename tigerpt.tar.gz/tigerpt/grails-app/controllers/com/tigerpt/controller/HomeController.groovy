package com.tigerpt.controller

import com.tigerpt.domain.Patient
import com.tigerpt.domain.Injury

class HomeController {

    def index() {
        def patientCount = Patient.count()
        def injuryCount = Injury.count()
        def recentPatients = Patient.list(max: 5, sort: 'id', order: 'desc')
        
        [
            patientCount: patientCount,
            injuryCount: injuryCount,
            recentPatients: recentPatients
        ]
    }
}
