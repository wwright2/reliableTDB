<!DOCTYPE html>
<html>
<head>
    <meta name="layout" content="main"/>
    <title>TigerPT - Home</title>
    <style>
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        .card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
        }
        .card h2 {
            margin: 0 0 10px 0;
            font-size: 48px;
        }
        .card p {
            margin: 0;
            font-size: 18px;
            opacity: 0.9;
        }
        .recent-patients {
            margin-top: 40px;
        }
        .recent-patients h3 {
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
        }
        .patient-list {
            list-style: none;
            padding: 0;
        }
        .patient-list li {
            background-color: #f8f9fa;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 4px solid #3498db;
        }
        .patient-list li:hover {
            background-color: #e9ecef;
            cursor: pointer;
        }
        .welcome {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 40px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        .welcome h2 {
            margin: 0 0 10px 0;
            font-size: 32px;
        }
        .welcome p {
            margin: 0;
            font-size: 18px;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="welcome">
        <h2>Welcome to TigerPT</h2>
        <p>National Trauma Data Standard (NTDS) Compliant Patient Tracking System</p>
    </div>

    <div class="dashboard">
        <div class="card">
            <h2>${patientCount}</h2>
            <p>Total Patients</p>
        </div>
        <div class="card">
            <h2>${injuryCount}</h2>
            <p>Recorded Injuries</p>
        </div>
    </div>

    <div class="recent-patients">
        <h3>Recent Patients</h3>
        <g:if test="${recentPatients}">
            <ul class="patient-list">
                <g:each in="${recentPatients}" var="patient">
                    <li onclick="window.location.href='${createLink(controller:'patient', action:'show', id:patient.id)}'">
                        <strong>${patient.lastName}, ${patient.firstName}</strong>
                        <g:if test="${patient.medicalRecordNumber}">
                            - MRN: ${patient.medicalRecordNumber}
                        </g:if>
                        <g:if test="${patient.dateOfBirth}">
                            - DOB: <g:formatDate date="${patient.dateOfBirth}" format="MM/dd/yyyy"/>
                        </g:if>
                    </li>
                </g:each>
            </ul>
        </g:if>
        <g:else>
            <p>No patients in the system yet.</p>
        </g:else>
    </div>

    <div style="margin-top: 40px; padding: 20px; background-color: #e8f4f8; border-radius: 5px;">
        <h3 style="color: #2c3e50; margin-top: 0;">Quick Links</h3>
        <ul style="list-style: none; padding: 0;">
            <li style="margin: 10px 0;">
                <g:link controller="patient" action="create" style="color: #3498db; text-decoration: none; font-size: 16px;">
                    ➕ Add New Patient
                </g:link>
            </li>
            <li style="margin: 10px 0;">
                <g:link controller="patient" action="index" style="color: #3498db; text-decoration: none; font-size: 16px;">
                    📋 View All Patients
                </g:link>
            </li>
            <li style="margin: 10px 0;">
                <g:link controller="injury" action="index" style="color: #3498db; text-decoration: none; font-size: 16px;">
                    🏥 View All Injuries
                </g:link>
            </li>
        </ul>
    </div>
</body>
</html>
