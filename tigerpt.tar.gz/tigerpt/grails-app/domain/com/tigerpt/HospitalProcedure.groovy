package com.tigerpt

import java.time.LocalDate
import java.time.LocalTime

class HospitalProcedure {

    String icd10Code
    String procedureDescription
    LocalDate procedureStartDate
    LocalTime procedureStartTime
    
    static belongsTo = [patient: Patient]
    
    static constraints {
        icd10Code nullable: true, maxSize: 20
        procedureDescription nullable: true, maxSize: 500
        procedureStartDate nullable: true
        procedureStartTime nullable: true
    }
    
    static mapping = {
        table 'hospital_procedure'
        version false
    }
    
    String toString() {
        return "Procedure: ${icd10Code} - ${procedureDescription}"
    }
}
