package com.tigerpt

import java.time.LocalDate
import java.time.LocalTime

class Patient {

    // Demographic Information
    String homeZipPostalCode
    String homeCountry
    String homeState
    String homeCounty
    String homeCity
    String alternateHomeResidence
    LocalDate dateOfBirth
    Integer age
    String ageUnits
    String race
    String ethnicity
    String sex
    
    // Pre-hospital Information
    String transportMode
    String otherTransportMode
    String emsPatientCareReportUuid
    Boolean interFacilityTransfer
    Boolean preHospitalCardiacArrest
    
    // Pre-existing Conditions
    Boolean advanceDirectiveLimitingCare
    Boolean alcoholUseDisorder
    Boolean anticoagulantTherapy
    Boolean addAdhd
    Boolean bipolarDisorder
    Boolean bleedingDisorder
    Boolean cerebralVascularAccident
    Boolean copd
    Boolean chronicRenalFailure
    Boolean cirrhosis
    Boolean congenitalAnomalies
    Boolean congestiveHeartFailure
    Boolean currentSmoker
    Boolean currentlyReceivingChemotherapy
    Boolean dementia
    Boolean diabetesMellitus
    Boolean disseminatedCancer
    Boolean functionallyDependent
    Boolean hypertension
    Boolean majorDepressiveDisorder
    Boolean myocardialInfarction
    Boolean otherMentalDisorders
    Boolean peripheralArterialDisease
    Boolean postTraumaticStressDisorder
    Boolean pregnancy
    Boolean prematurity
    Boolean schizoaffectiveDisorder
    Boolean schizophrenia
    
    // Relationships
    InjuryInformation injury
    EmergencyDepartmentInfo edInfo
    Disposition disposition
    
    static hasMany = [procedures: HospitalProcedure]
    
    static constraints {
        homeZipPostalCode nullable: true, maxSize: 20
        homeCountry nullable: true, maxSize: 100
        homeState nullable: true, maxSize: 100
        homeCounty nullable: true, maxSize: 100
        homeCity nullable: true, maxSize: 100
        alternateHomeResidence nullable: true, maxSize: 255
        dateOfBirth nullable: true
        age nullable: true
        ageUnits nullable: true, maxSize: 20
        race nullable: true, maxSize: 100
        ethnicity nullable: true, maxSize: 100
        sex nullable: true, maxSize: 20
        transportMode nullable: true, maxSize: 100
        otherTransportMode nullable: true, maxSize: 255
        emsPatientCareReportUuid nullable: true, maxSize: 255
        interFacilityTransfer nullable: true
        preHospitalCardiacArrest nullable: true
        
        // Pre-existing conditions
        advanceDirectiveLimitingCare nullable: true
        alcoholUseDisorder nullable: true
        anticoagulantTherapy nullable: true
        addAdhd nullable: true
        bipolarDisorder nullable: true
        bleedingDisorder nullable: true
        cerebralVascularAccident nullable: true
        copd nullable: true
        chronicRenalFailure nullable: true
        cirrhosis nullable: true
        congenitalAnomalies nullable: true
        congestiveHeartFailure nullable: true
        currentSmoker nullable: true
        currentlyReceivingChemotherapy nullable: true
        dementia nullable: true
        diabetesMellitus nullable: true
        disseminatedCancer nullable: true
        functionallyDependent nullable: true
        hypertension nullable: true
        majorDepressiveDisorder nullable: true
        myocardialInfarction nullable: true
        otherMentalDisorders nullable: true
        peripheralArterialDisorder nullable: true
        postTraumaticStressDisorder nullable: true
        pregnancy nullable: true
        prematurity nullable: true
        schizoaffectiveDisorder nullable: true
        schizophrenia nullable: true
        
        injury nullable: true
        edInfo nullable: true
        disposition nullable: true
    }
    
    static mapping = {
        table 'patient'
        version false
        injury cascade: 'all-delete-orphan'
        edInfo cascade: 'all-delete-orphan'
        disposition cascade: 'all-delete-orphan'
    }
    
    String toString() {
        return "Patient ${id} - Age: ${age}"
    }
}
