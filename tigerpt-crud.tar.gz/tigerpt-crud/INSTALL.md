# TigerPT CRUD Views - Installation Guide

## Quick Install (2 minutes)

### Step 1: Copy Controllers
Copy all `.groovy` files from `controllers/` to your tigerpt project:
```
tigerpt/grails-app/controllers/com/tigerpt/
```

Files to copy:
- PatientController.groovy
- ImportController.groovy

### Step 2: Copy Views
Copy all view directories to your tigerpt project:
```
tigerpt/grails-app/views/
```

Directories to copy:
- patient/
- import/
- index.gsp (root level)

### Step 3: Restart Application
```bash
cd tigerpt
./gradlew clean bootRun
```

### Step 4: Access
Navigate to:
```
http://localhost:8080
```

## What You Get

### Patient CRUD
- **List**: `/patient/index` - View all patients
- **Create**: `/patient/create` - Add new patient
- **View**: `/patient/show/1` - View patient details
- **Edit**: `/patient/edit/1` - Edit patient
- **Delete**: Delete button on list/show pages

### XML Import
- **Import**: `/import/index` - Upload Idaho_Sample.xml

### Home Dashboard
- **Dashboard**: `/` - Links to all modules

## Test with Idaho Sample Data

1. Go to `/import/index`
2. Upload the `Idaho_Sample.xml` file
3. Click "Import Data"
4. View imported patients at `/patient/index`

## Matching Your Database

The views are designed to work with your existing MySQL schema based on the Idaho XML structure:

**Patient fields:**
- patientId, facilityId
- patientFirstName, patientLastName, patientMiddleName
- socialSecurityNumber, dateOfBirth, age, sex
- homeZip, homeState, homeCounty
- medicalRecordNumber

**Injury fields:**
- incidentDate, incidentTime
- workRelated, traumaType
- emsAgencyId, transportMode
- sbp, dbp, pulseRate, temperature
- gcsEye, gcsVerbal, gcsMotor, totalGcs
- edDischargeDisposition

## Troubleshooting

### View not found error
Make sure views are in correct location:
```
grails-app/views/patient/index.gsp
grails-app/views/patient/show.gsp
grails-app/views/patient/create.gsp
grails-app/views/patient/edit.gsp
```

### Controller not found
Ensure controllers are in:
```
grails-app/controllers/com/tigerpt/PatientController.groovy
```

### Domain class mismatch
If field names don't match, edit the GSP files to match your actual domain class properties.

## Files Included

Controllers (2):
- PatientController.groovy
- ImportController.groovy

Views (6):
- patient/index.gsp
- patient/show.gsp
- patient/create.gsp
- patient/edit.gsp
- import/index.gsp
- index.gsp

Total: 8 files ready to use with your existing tigerpt MySQL app!
