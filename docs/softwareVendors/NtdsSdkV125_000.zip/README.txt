===========================
README for v1.2.5 NTDS SDK
===========================

Please refer to the bottom of this README for release notes.

In the file NtdsSdkV125.zip you'll find the following contents:

Place this first set of files wherever you'd like to install them relative to your development environment or application.
Preserve the NTDSSDK directory structure relative to the DLL location in order for the DLL to find the additional files that it needs.
There are no other special installation requirements required other than copying the files to the location of your choice.
NTDSSDK.DLL
NTDSSDK\ASTEXT.IDX (descriptions have been stripped from this)
NTDSSDK\INMENU.IDX
NTDSSDK\NTDS.NSL
NTDSSDK\NTDS.IDX
NTDSSDK\RULEID.IDX
NTDSSDK\DTEARLY.CSV
NTDSSDK\DTLATER.CSV
NTDSSDK\DTRANGE.CSV
NTDSSDK\IFVALUE1.CSV
NTDSSDK\IFVALUE2.CSV
NTDSSDK\IFVALUE3.CSV
NTDSSDK\INTRANGE.CSV
NTDSSDK\LOSDIFF.csv
NTDSSDK\SDTERLTM.CSV
NTDSSDK\SDTLTRTM.CSV

Use the following 2 files for demonstration purposes only.  They are provided so that you can see an example of the SDK's output.  
TESTNTDS.EXE
NTDS_EXAMPLE.XML

Documentation files:
NTDS SDK Programmers Guide v1.2.5.pdf - This Guide describes the various Functions that form the bulk of the SDK and how they are typically used.
NtdsSchema v1.2.5.xsd - The most current XSD version.


-------------------

To run the demonstration ensure the two example files are located in the same directory as the DLL and follow these steps:


1. Open a CMD window (DOS prompt)
2. Change path to the directory with the EXE file in it
3. Type: testntds xmlFile logFile validationLevel [workingPath]
         i.e. testntds test.xml test.log 5 .\
   (Where logFile is a file name of your choice,
   validationLevel is either a 1, 2, 3, 4 or 5,
   workingPath is optional)
4. After running, view the contents of your logFile to see something like
   the following (this was produced at validationLevel=5):

99999,11,1,IncidentCity,1,2401,Invalid value
99999,11,1,RespiratoryAssistance,4,5102,"Blank, required field"
99999,11,1,SupplementalOxygen,4,5302,"Blank, required field"
99999,11,1,DeathInEd,3,6206,"Not Known, required Inclusion Criterion"
99999,11,1,HomeZip,5,0003,"Not Applicable, complete variable: Alternate Home Residence"
99999,11,1,AisCodes[].AisPredot,5,7002,"If completed, then AIS Severity must be completed."
99999,11,1,AisCodes[].IssRegion,5,7202,"If completed, then AIS Severity must be completed."
99999,11,1,AisCodes[].AisPredot,5,7003,"If completed, then AIS Version must be completed."
99999,11,1,AisCodes[].IssRegion,5,7203,"If completed, then AIS Version must be completed."
99999,11,1,RespiratoryRate,5,5004,"If completed, then Initial Ed/Hospital Respiratory Assistance must be completed."
99999,11,1,WorkRelated,5,1404,"If completed, then Patient Occupation must be completed"
99999,11,1,WorkRelated,5,1403,"If completed, then Patient�s Occupational Industry must be completed"
99999,11,1,PulseOximetry,5,5203,"If completed, then Initial Ed/Hospital Supplemental Oxygen must be completed"
99999,11,1,HomeResidence,5,0503,"Blank, required to complete variables: Patient�s Home Zip Code or (Patient�s Home Country, Patient�s Home State, Patient�s Home County and Patient�s Home City)"
99999,11,1,ProtectiveDevices[].ProtectiveDevice,5,2503,If Protective Device = 6 (Child Restraint) then Child Specific Restraint must be completed
99999,11,1,ProtectiveDevices[].ProtectiveDevice,5,2504,If Protective Device = 8 (Airbag Present) then Airbag Deployment must be completed
99999,11,1,AisCodes[].AisSeverity,4,7103,"Blank, required to complete when AIS PreDot Code is complete"
99999,11,1,SupplementalOxygen,4,5303,"Blank, required to complete when Initial ED/Hospital Oxygen Saturation is complete"
99999,11,1,RespiratoryAssistance,4,5103,"Blank, required to complete when Initial ED/Hospital Respiratory Rate is complete"
99999,11,1,HomeResidence,4,0502,"Blank, required to complete when Patient�s Home Zip Code is Not Applicable"
99999,11,1,PatientsOccupationalIndustry,4,1504,"Blank, required to complete when Work-Related is 1 (Yes)"
99999,11,1,PatientsOccupation,4,1604,"Blank, required to complete when Work-Related is 1 (Yes)"
99999,11,1,DeathInEd,3,6204,If Ed Discharge Disposition <> 5 (Died) then Ed Death should be BIU = 1
99999,11,1,HospitalProcedures[].HospitalProcedureStartTime,4,6703,"If Hospital Procedure Start Date and EMS Dispatch Date are the same, the Hospital Procedure Start Time cannot be earlier than the EMS Dispatch Time"
99999,11,1,HospitalProcedures[].HospitalProcedureStartTime,4,6704,"If Hospital Procedure Start Date and EMS Unit Arrival on Scene Date are the same, the Hospital Procedure Start Time cannot be earlier than the EMS Unit Arrival on Scene Time"
99999,11,1,HospitalProcedures[].HospitalProcedureStartTime,4,6705,"if Hospital Procedure Start Date and EMS Unit Scene Departure Date are the same, the Hospital Procedure Start Time cannot be earlier than the EMS Unit Scene Departure Time"
99999,11,1,HospitalProcedures[].HospitalProcedureStartTime,4,6706,"If Hospital Procedure Start Date and ED/Hospital Arrival Date are the same, the Hospital Procedure Start Time cannot be earlier than the ED/Hospital Arrival Time"
99999,11,1,Age,3,0704,Ed/Hospital Arrival Date minus Date of Birth must equal submitted Age

These errors are all deliberate to demonstrate the various types of error checking that the SDK performs.  The first column of the file is the Record # followed by the error type (1=Format/Schema; 2=Inclusion Criteria; 3=Major Logic; 4=Minor Logic; 5=Data Entry Prompts ) and then an English description of the error.

If any problems with installation or usage arise please contact NtdsSdkSupport@dicorp.com with your questions.  A member of DI support staff will get back to you.



---------------
Known Issues
===============
None


--------------------------------------
v1.2.5 Fixed the following issue(s):
======================================
Please reference "v125 Release Notes.doc".


--------------------------------------
v1.2.4 Fixed the following issue(s):
======================================
1.  Age check takes into account the Age Units field as well.  Also, the check occurs only if AGE is valued or DOB is less than 24 hours or AGE is "Not Recorded" or "Not Known".

    0704, 3, Ed/Hospital Arrival Date minus Date of Birth must equal submitted Age.

2.  Incident City length was corrected to 5. (It was 10).

3.  Temperature changed from Int to Decimal to allow 1 decimal. (XSD and Data Dictionary have also changed.)

4.  ValidateNtdsFile function takes an extra parameter to accept validationLevel. The previous behavior was to generate errors for all Error Levels which was inappropriate if the developer did not want data entry prompts (Level 5). 

5.  The DLL no longer changes working directory.  This used to happen when calling InitializeNtdsSdk.  Now the DLL remembers the working directory that is passed in and creates the temp files using that directory and the tmpnam function to build the filename. This package now has a new Testntds.exe.  The new exe now takes 1 additional parameter for the working path, which is optional.  Usage is as follows:      

	testntds xmlFile logFile validationLevel [workingPath]

	e.g. testntds_dir test.xml test.log 5 .\


--------------------------------------
v1.2.3 Fixed the following issue(s):
======================================
1.  Corrected AIS Severity to allow a valid value of 9.

2.  Corrected Temperature max to 45 C.

3.  Corrected memory issues that produced an EOF error when calling ValidateNextNtdsRecord.

4.  (a) Rules 3601, 3701, 3801, 3901, 4701, 4901, 5001, 4801 and 5201 were modified to only enforce a length check and no longer enforce a range check.
    (b) Rules 3603, 3703, 3803, 3903, 4704, 4903, 5005, 4804 and 5204 were added to enforce a range check. 
	These new error checks are level 3. Previously, if the value submitted was outside the NTDS range, it was causing an error level 1 and the file would be rejected.

	These changes were made for the following fields:

	EmsPulseOximetry
        EmsPulseRate
        EmsRespiratoryRate
        EmsSbp
	PulseOximetry
        PulseRate
        RespiratoryRate
        Sbp
        Temperature

5.  The Validator rule 6502 changed to only check procedures that have values (not blank or biu) in all 3 fields: HospitalProcedure, HospitalProcedureStartDate, and HospitalProcedureStartTime.

            6502 'Procedures with the same code cannot have the same Hospital Procedure Start Date and Time'

    That is, if these values are blank or BIU then 6502 will not be triggered.  If Time or Date are BIU in one or both of the variables,
    the procedures are not considered identical.

6.  Modified rule 6202 "Blank, required field" for EdDeath to be produced, so it now performs the following check:
	  If EdDeath is blank OR (BIU=1 AND EdDischargeDisposition=5).

    Previously, a BIU=1 for EdDeath would produce this error, even though the EdDischargeDisposition <> 5 (the patient is alive).  
    By including this extra criteria we are allowing a BIU=1 when it is valid.


--------------------------------------
v1.2.2 Fixed the following issue(s):
======================================
1. Submitting a null value (BIU) for ED Discharge Disposition, ED Death, Hospital Discharge Disposition will now produce an error level 3, changed from 2, therefore no longer resulting in a file rejection.

2. When a time field contains invalid characters such as non-numeric, the rule returned was "Time out of range" and "Blank, required field" (where applicable) rather than the expected "Invalid Value".  Now the correct rule "Invalid Value" is returned.

Some examples:

<EdDischargeTime>a</EdDischargeTime> 
<EmsArrivalTime>a</EmsArrivalTime> 
<HospitalArrivalTime>0a0000</HospitalArrivalTime> 
<IncidentTime>a00</IncidentTime>

3. LocationEcode was not validating properly.  A valid value of 0-9 was producing the error �Invalid, out of range�.

4. AIS Codes allow a biu value to be submitted without file rejection.

5. There were BIU handling discrepancies that were fixed.  For example, a biu=3 for LastModifiedDateTime was not generating an error previously.  

6. An element omitted entirely from the XML file was not generating a Validator error when it should.

7. Rules 6902 "Blank, required field" and 6903 "At least one diagnosis must be provided and meet inclusion criteria (800 - 959.9, except for 905 - 909.9, 910 - 924.9, 930 - 939.9)" for Injury Diagnoses are now handled as a group.  Previously, these were validating each diagnosis code separately.

8.  Improved speed/performance.

9.  A Fatal Error was produced if a file was opened from the directory the Validator was running in.  This no longer occurs.


--------------------------------------
v1.2.1 Fixed the following issue(s):
======================================
1.  A XML file with more than one NtdsRecord element was not validating correctly.  The first record validated correctly,
 however, subsequent records did not.  Subsequent records were missing the FacilityId, PatientId, as well as receiving 
"Invalid Value" or "Time Out of Range" error messages for almost all fields.

2. If there is a date value < 1900, the internal date value is handled as a negative number and incorrectly triggers some date comparison Rule IDs.  Below is an example:

With DOB = 01/01/1899 and Injury Incident Date = 01/01/1999, rule 1204 "Injury Incident Date cannot be earlier than Date of Birth" is produced in error.
